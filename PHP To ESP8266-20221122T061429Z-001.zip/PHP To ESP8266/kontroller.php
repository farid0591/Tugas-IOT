<form method="post" action="hidup.php">
    <button type="submit">Hidup</button>
</form>
<form method="post" action="mati.php">
    <button type="submit">Mati</button>
</form>